<?php $__env->startSection('title','CODY || Chỉnh sửa Tin Tức Công Ty'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="card">
    <h5 class="card-header">Chỉnh Sửa Tin Tức</h5>
    <div class="card-body">
      <form method="post" action="<?php echo e(route('company_news.update', $news->id)); ?>" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> 
        <?php echo method_field('PATCH'); ?>

        <div class="form-group">
          <label for="title" class="col-form-label">Tiêu đề <span class="text-danger">*</span></label>
          <input id="title" type="text" name="title" value="<?php echo e($news->title); ?>" class="form-control">
          <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
          <label for="content" class="col-form-label">Nội dung <span class="text-danger">*</span></label>
          <textarea class="form-control" id="content" name="content"><?php echo e($news->content); ?></textarea>
          <?php $__errorArgs = ['content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
          <label for="image" class="col-form-label">Ảnh</label>
          <input type="file" class="form-control" name="image">
          <?php if($news->image): ?>
            <img src="<?php echo e(asset('storage/'.$news->image)); ?>" class="img-fluid mt-2" style="max-width:80px">
          <?php endif; ?>
        </div>

        <div class="form-group">
          <label for="published_at" class="col-form-label">Ngày xuất bản</label>
          <input type="date" class="form-control" name="published_at" value="<?php echo e($news->published_at); ?>">
        </div>

        <div class="form-group">
          <button type="reset" class="btn btn-warning">Đặt lại</button>
          <button class="btn btn-success" type="submit">Cập nhật</button>
        </div>
      </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/summernote/summernote.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/summernote/summernote.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
      $('#message').summernote({
        placeholder: "Nhập tin tức.....",
          tabsize: 2,
          height: 150
      });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/summernote/summernote.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/summernote/summernote.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
      $('#message').summernote({
        placeholder: "Nhập tin tức...",
          tabsize: 2,
          height: 150
      });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\van08\Downloads\CODYADMIN\resources\views\backend\company_news\edit.blade.php ENDPATH**/ ?>