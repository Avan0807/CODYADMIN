<div id="notifications">
    <?php if(Auth::check()): ?> 
        <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-bell fa-fw"></i>
            <!-- Counter - Alerts -->
            <span class="badge badge-danger badge-counter">
                <?php if(Auth::user()->unreadNotifications->count() > 5): ?>
                    <span data-count="5" class="count">5+</span>
                <?php else: ?>
                    <span class="count" data-count="<?php echo e(Auth::user()->unreadNotifications->count()); ?>"><?php echo e(Auth::user()->unreadNotifications->count()); ?></span>
                <?php endif; ?>
            </span>
        </a>

        <!-- Dropdown - Alerts -->
        <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="alertsDropdown">
            <h6 class="dropdown-header">
                Trung tâm thông báo
            </h6>

            <?php $__currentLoopData = Auth::user()->unreadNotifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="dropdown-item d-flex align-items-center" target="_blank" href="<?php echo e(route('admin.notification', $notification->id)); ?>">
                    <div class="mr-3">
                        <div class="icon-circle bg-primary">
                            <?php if(isset($notification->data['fas'])): ?>
                                <i class="fas <?php echo e($notification->data['fas']); ?> text-white"></i>
                            <?php else: ?>
                                <i class="fas fa-info-circle text-white"></i> <!-- Icon mặc định nếu thiếu -->
                            <?php endif; ?>
                        </div>
                    </div>
                    <div>
                        <div class="small text-gray-500"><?php echo e($notification->created_at->format('F d, Y h:i A')); ?></div>
                        <span class="<?php if($notification->unread()): ?> font-weight-bold <?php else: ?> small text-gray-500 <?php endif; ?>">
                            <?php echo e($notification->data['title'] ?? 'Thông báo mới'); ?>

                        </span>
                    </div>
                </a>
                <?php if($loop->index + 1 == 5): ?>
                    <?php break; ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <a class="dropdown-item text-center small text-gray-500" href="<?php echo e(route('all.notification')); ?>">Hiển thị tất cả thông báo</a>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\van08\Downloads\CODYADMIN\resources\views\backend\notification\show.blade.php ENDPATH**/ ?>