<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Xác minh số điện thoại của bạn')); ?></div>

                <div class="card-body">
                    <?php if(session('resent')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(__('Một mã xác minh mới đã được gửi tới số điện thoại của bạn.')); ?>

                        </div>
                    <?php endif; ?>

                    <?php echo e(__('Trước khi tiếp tục, vui lòng kiểm tra tin nhắn SMS để biết mã xác minh.')); ?>

                    <?php echo e(__('Nếu bạn không nhận được tin nhắn')); ?>,
                    <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-link p-0 m-0 align-baseline"><?php echo e(__('nhấp vào đây để yêu cầu mã khác')); ?></button>.
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\van08\Downloads\CODYADMIN\resources\views\auth\verify.blade.php ENDPATH**/ ?>