<?php $__env->startSection('title','Quản lý Đơn Hàng Affiliate'); ?>

<?php $__env->startSection('main-content'); ?>
<div class="card">
    <div class="row">
        <div class="col-md-12">
            <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <h5 class="card-header">Danh sách đơn hàng Affiliate</h5>
    <div class="card-body">
        <?php if($affiliateOrders->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-bordered table-hover" id="affiliate-orders-dataTable">
                <thead class="thead-light">
                    <tr>
                        <th>#</th>
                        <th>Bác sĩ</th>
                        <th>Mã đơn hàng</th>
                        <th>Hoa hồng</th>
                        <th>Trạng thái</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $affiliateOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($order->doctor->name); ?></td>
                        <td><?php echo e($order->order->order_number); ?></td>
                        <td><?php echo e(number_format($order->commission, 0, ',', '.')); ?> VNĐ</td>
                        <td>
                            <?php
                                $statusClass = [
                                    'new' => 'primary',       // Xanh dương
                                    'process' => 'warning',   // Vàng
                                    'delivered' => 'success', // Xanh lá
                                    'cancel' => 'danger'      // Đỏ
                                ];
                            ?>
                            <span class="badge badge-<?php echo e($statusClass[$order->status] ?? 'secondary'); ?>">
                                <?php echo e(ucfirst($order->status)); ?>

                            </span>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="float-right">
                <?php echo e($affiliateOrders->links()); ?>

            </div>
        </div>
        <?php else: ?>
            <h2 class="text-center">Không có đơn hàng nào!</h2>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link href="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" />
<style>
    .table thead th {
        background-color: #f8f9fa;
    }
    .badge {
        font-size: 14px;
        padding: 6px 10px;
        border-radius: 5px;
    }
    .btn-sm {
        width: 32px;
        height: 32px;
        display: inline-flex;
        justify-content: center;
        align-items: center;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

<script>
    $(document).ready(function(){
        $('#affiliate-orders-dataTable').DataTable({
            "paging": false, // Vô hiệu hóa phân trang của DataTables
            "searching": true, // Giữ lại tìm kiếm
            "info": false, // Ẩn hiển thị tổng số dòng
            "ordering": true, // Cho phép sắp xếp
            "columnDefs": [
                { "orderable": false, "targets": [5] } // Chặn sắp xếp cột hành động
            ]
        });
    });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\van08\Downloads\CODYADMIN\resources\views\backend\affiliate_orders\index.blade.php ENDPATH**/ ?>