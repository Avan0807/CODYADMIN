<!DOCTYPE html>
<html lang="en">
<?php echo $__env->make('backend.layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Load head chuẩn -->

<body id="page-top">
    <div id="wrapper">
        <?php echo $__env->make('backend.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Sidebar -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php echo $__env->make('backend.layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Header -->
                <?php echo $__env->yieldContent('main-content'); ?> <!-- Nội dung chính -->
            </div>
            <?php echo $__env->make('backend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!-- Footer -->
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\Users\van08\Downloads\CODYADMIN\resources\views\backend\layouts\master.blade.php ENDPATH**/ ?>