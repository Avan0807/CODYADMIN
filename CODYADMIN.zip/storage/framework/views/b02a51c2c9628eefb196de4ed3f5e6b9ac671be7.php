<?php $__env->startSection('title','CODY || Chỉnh sửa thông báo chiến dịch'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="card">
    <h5 class="card-header">Chỉnh sửa Thông báo Chiến dịch</h5>
    <div class="card-body">
      <form method="post" action="<?php echo e(route('campaign_notifications.update', $campaign_notification->id)); ?>">
        <?php echo csrf_field(); ?> 
        <?php echo method_field('PATCH'); ?>

        <div class="form-group">
          <label for="inputTitle" class="col-form-label">Tiêu đề <span class="text-danger">*</span></label>
          <input id="inputTitle" type="text" name="title" placeholder="Nhập tiêu đề" value="<?php echo e($campaign_notification->title); ?>" class="form-control">
          <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
          <label for="message" class="col-form-label">Nội dung <span class="text-danger">*</span></label>
          <textarea class="form-control" id="message" name="message"><?php echo e($campaign_notification->message); ?></textarea>
          <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group">
          <label for="target_audience" class="col-form-label">Đối tượng nhận <span class="text-danger">*</span></label>
          <select name="target_audience" class="form-control">
              <option value="all" <?php echo e($campaign_notification->target_audience == 'all' ? 'selected' : ''); ?>>Tất cả</option>
              <option value="doctors" <?php echo e($campaign_notification->target_audience == 'doctors' ? 'selected' : ''); ?>>Bác sĩ</option>
              <option value="patients" <?php echo e($campaign_notification->target_audience == 'patients' ? 'selected' : ''); ?>>Bệnh nhân</option>
          </select>
          <?php $__errorArgs = ['target_audience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <span class="text-danger"><?php echo e($message); ?></span>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="form-group mb-3">
           <button class="btn btn-success" type="submit">Cập nhật</button>
        </div>
      </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/summernote/summernote.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/summernote/summernote.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
      $('#message').summernote({
        placeholder: "Nhập nội dung thông báo.....",
          tabsize: 2,
          height: 150
      });
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('backend/summernote/summernote.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="<?php echo e(asset('backend/summernote/summernote.min.js')); ?>"></script>
<script>
    $(document).ready(function() {
      $('#message').summernote({
        placeholder: "Nhập phòng khám...",
          tabsize: 2,
          height: 150
      });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\van08\Downloads\CODYADMIN\resources\views\backend\campaign_notifications\edit.blade.php ENDPATH**/ ?>