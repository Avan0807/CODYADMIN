<?php $__env->startSection('main-content'); ?>
 <!-- DataTales Example -->
 <div class="card shadow mb-4">
     <div class="row">
         <div class="col-md-12">
            <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
     </div>
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary float-left">Danh sách bác sĩ</h6>
      <a href="<?php echo e(route('doctor.create')); ?>" class="btn btn-primary btn-sm float-right" data-toggle="tooltip" data-placement="bottom" title="Thêm bác sĩ"><i class="fas fa-plus"></i> Thêm bác sĩ</a>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <?php if(count($doctors)>0): ?>
        <table class="table table-bordered table-hover" id="doctor-dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>#</th>
              <th>Tên</th>
              <th>Chuyên môn</th>
              <th>Kinh nghiệm</th>
              <th>Giờ làm việc</th>
              <th>Địa điểm</th>
              <th>Email</th>
              <th>Điện thoại</th>
              <th>Ảnh</th>
              <th>Trạng thái</th>
              <th>Chức năng</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($doctor->id); ?></td>
                    <td><?php echo e($doctor->name); ?></td>
                    <td><?php echo e($doctor->specialization); ?></td>
                    <td><?php echo e($doctor->experience); ?> năm</td>
                    <td><?php echo e($doctor->working_hours); ?></td>
                    <td><?php echo e($doctor->location); ?></td>
                    <td><?php echo e($doctor->email); ?></td>
                    <td><?php echo e($doctor->phone); ?></td>
                    <td>
                        <?php if($doctor->photo): ?>
                            <img src="<?php echo e($doctor->photo); ?>" class="img-fluid zoom" style="max-width:80px" alt="Ảnh bác sĩ">
                        <?php else: ?>
                            <img src="<?php echo e(asset('backend/img/thumbnail-default.jpg')); ?>" class="img-fluid" style="max-width:80px" alt="avatar.png">
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php if($doctor->status=='active'): ?>
                            <span class="badge badge-success"><?php echo e($doctor->status); ?></span>
                        <?php else: ?>
                            <span class="badge badge-warning"><?php echo e($doctor->status); ?></span>
                        <?php endif; ?>
                    </td>
                    <td>
                        <a href="<?php echo e(route('doctor.edit',$doctor->id)); ?>" class="btn btn-primary btn-sm float-left mr-1" style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip" title="Chỉnh sửa" data-placement="bottom"><i class="fas fa-edit"></i></a>
                        <form method="POST" action="<?php echo e(route('doctor.destroy',[$doctor->id])); ?>">
                          <?php echo csrf_field(); ?>
                          <?php echo method_field('delete'); ?>
                          <button class="btn btn-danger btn-sm dltBtn" data-id=<?php echo e($doctor->id); ?> style="height:30px; width:30px;border-radius:50%" data-toggle="tooltip" data-placement="bottom" title="Xóa"><i class="fas fa-trash-alt"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <span style="float:right"><?php echo e($doctors->links()); ?></span>
        <?php else: ?>
          <h6 class="text-center">Không tìm thấy bác sĩ nào!!! Vui lòng thêm bác sĩ</h6>
        <?php endif; ?>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
  <link href="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
  <style>
      .zoom {
        transition: transform .2s;
      }
      .zoom:hover {
        transform: scale(2);
      }
  </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
  <!-- DataTables scripts -->
  <script src="<?php echo e(asset('backend/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>

  <script>
      $(document).ready(function(){
          $('#doctor-dataTable').DataTable({
              "scrollX": false,
              "language": {
                  "decimal": "",
                  "emptyTable": "Không có dữ liệu",
                  "info": "Hiển thị _START_ đến _END_ của _TOTAL_ bác sĩ",
                  "infoEmpty": "Hiển thị 0 đến 0 của 0 bác sĩ",
                  "infoFiltered": "(lọc từ _MAX_ tổng số bác sĩ)",
                  "lengthMenu": "Hiển thị _MENU_ bác sĩ mỗi trang",
                  "loadingRecords": "Đang tải...",
                  "processing": "Đang xử lý...",
                  "search": "Tìm kiếm:",
                  "zeroRecords": "Không tìm thấy kết quả nào",
                  "paginate": {
                      "first": "Đầu",
                      "last": "Cuối",
                      "next": "Tiếp",
                      "previous": "Trước"
                  },
                  "aria": {
                      "sortAscending": ": sắp xếp tăng dần",
                      "sortDescending": ": sắp xếp giảm dần"
                  }
              },
              "columnDefs": [
                  {
                      "orderable": false,
                      "targets": [8,9,10]  // Không sắp xếp các cột ảnh, trạng thái, chức năng
                  }
              ]
          });

          // Xác nhận xóa bằng SweetAlert
          $('.dltBtn').click(function(e){
              var form=$(this).closest('form');
              e.preventDefault();
              swal({
                  title: "Bạn có chắc không?",
                  text: "Sau khi xóa, bạn sẽ không thể khôi phục dữ liệu này!",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
              }).then((willDelete) => {
                  if (willDelete) {
                     form.submit();
                  } else {
                      swal("Dữ liệu của bạn an toàn!");
                  }
              });
          });
      });
  </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\van08\Downloads\CODYADMIN\resources\views\backend\doctor\index.blade.php ENDPATH**/ ?>