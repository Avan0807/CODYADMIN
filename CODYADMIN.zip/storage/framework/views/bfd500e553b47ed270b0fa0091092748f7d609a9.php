<?php $__env->startSection('main-content'); ?>
 <!-- Danh sách đơn hàng tiếp thị liên kết -->
 <div class="card shadow mb-4">
     <div class="row">
         <div class="col-md-12">
            <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
     </div>
    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary float-left">Danh sách đơn hàng tiếp thị liên kết</h6>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <?php if($affiliateLinks->count() > 0): ?>
        <table class="table table-bordered table-hover" id="affiliateLinks-dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
                <th>#</th>
                <th>Bác sĩ</th>
                <th>Sản phẩm</th>
                <th>Hoa hồng</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $affiliateLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $affiliate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($affiliate->id); ?></td>

                    <!-- Hiển thị bác sĩ -->
                    <td><?php echo e(optional($affiliate->doctor)->name ?? 'Chưa có bác sĩ'); ?></td>

                    <!-- Hiển thị sản phẩm -->
                    <td>
                        <?php if($affiliate->product): ?>
                            <a href="<?php echo e($affiliate->product_link); ?>" target="_blank">
                                <?php echo e($affiliate->product->title); ?>

                            </a>
                        <?php else: ?>
                            <span class="text-danger">Chưa có sản phẩm</span>
                        <?php endif; ?>
                    </td>

                    <!-- Ô nhập % hoa hồng (có tự động lưu) -->
                    <td>
                        <div class="input-group">
                            <input type="number" class="form-control commission-input"
                                   data-id="<?php echo e($affiliate->id); ?>"
                                   value="<?php echo e(number_format($affiliate->commission_percentage, 2)); ?>"
                                   min="0" max="100" step="0.01">
                            <div class="input-group-append">
                                <span class="input-group-text">%</span>
                            </div>
                        </div>
                        <small class="text-success commission-status d-none">✔ Đã lưu</small>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <span style="float:right"><?php echo e($affiliateLinks->links()); ?></span>
        <?php else: ?>
          <h6 class="text-center">Không tìm thấy đơn hàng nào! Vui lòng kiểm tra lại dữ liệu.</h6>
        <?php endif; ?>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
  <link href="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>

  <!-- Page level plugins -->
  <script src="<?php echo e(asset('backend/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

  <!-- Custom scripts -->
  <script>
      $(document).ready(function(){
          $.ajaxSetup({
              headers: {
                  'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
              }
          });

          // Cấu hình DataTables với ngôn ngữ Tiếng Việt
          $('#affiliateLinks-dataTable').DataTable({
              "ordering": true,
              "searching": true,
              "paging": true,
              "lengthMenu": [10, 25, 50, 100],
              "columnDefs": [ { "orderable": false, "targets": [3] } ],
              "language": {
                  "sProcessing":   "Đang xử lý...",
                  "sLengthMenu":   "Hiển thị _MENU_ dòng",
                  "sZeroRecords":  "Không tìm thấy dữ liệu phù hợp",
                  "sInfo":         "Hiển thị _START_ đến _END_ của _TOTAL_ mục",
                  "sInfoEmpty":    "Không có dữ liệu",
                  "sInfoFiltered": "(được lọc từ tổng số _MAX_ mục)",
                  "sSearch":       "Tìm kiếm:",
                  "oPaginate": {
                      "sFirst":    "Đầu",
                      "sPrevious": "Trước",
                      "sNext":     "Tiếp",
                      "sLast":     "Cuối"
                  }
              }
          });
      });
  </script>

<script>
    $(document).ready(function () {
        $('.commission-input').on('change blur keypress', function (event) {
            if (event.type === "keypress" && event.which !== 13) return;

            let inputField = $(this);
            let commissionValue = inputField.val();
            let affiliateId = inputField.data('id');
            let statusMessage = inputField.closest('td').find('.commission-status');
            let url = "<?php echo e(route('products-affiliate.update-commission', ':id')); ?>".replace(':id', affiliateId);

            // Hiện loading khi đang cập nhật
            inputField.prop('disabled', true);
            statusMessage.text('⏳ Đang cập nhật...').removeClass('d-none text-success').addClass('text-warning');

            $.ajax({
                url: url,
                type: 'POST',
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    commission_percentage: commissionValue
                },
                success: function (response) {
                    inputField.prop('disabled', false);
                    statusMessage.text('✔ Đã lưu').removeClass('text-warning').addClass('text-success').fadeIn().delay(1000).fadeOut();
                },
                error: function (xhr) {
                    inputField.prop('disabled', false);
                    swal("Lỗi!", "Không thể cập nhật hoa hồng, thử lại sau!", "error");
                }
            });
        });
    });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\van08\Downloads\CODYADMIN\resources\views/backend/product_affiliate/index.blade.php ENDPATH**/ ?>