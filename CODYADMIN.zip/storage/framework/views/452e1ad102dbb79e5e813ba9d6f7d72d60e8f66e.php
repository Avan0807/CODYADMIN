<?php $__env->startSection('title','Hồ sơ quản trị'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="card shadow mb-4">
    <div class="row">
        <div class="col-md-12">
           <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div class="card-header py-3">
        <h4 class="font-weight-bold">Hồ sơ</h4>
        <ul class="breadcrumbs">
            <li><a href="<?php echo e(route('admin')); ?>" style="color:#999">Trang tổng quan</a></li>
            <li><a href="" class="active text-primary">Trang hồ sơ</a></li>
        </ul>
    </div>
    <div class="card-body">
        <div class="row">
            <!-- Profile Card -->
            <div class="col-md-4">
                <div class="card">
                    <div class="image">
                        <img class="card-img-top img-fluid rounded-circle mt-4"
                            style="border-radius:50%;height:80px;width:80px;margin:auto; object-fit: cover;"
                            src="<?php echo e($profile->photo ?? asset('backend/img/avatar.png')); ?>"
                            alt="profile picture">
                    </div>
                    <div class="card-body mt-4 ml-2">
                        <h5 class="card-title text-left"><small><i class="fas fa-user"></i> <?php echo e($profile->name); ?></small></h5>
                        <p class="card-text text-left"><small><i class="fas fa-envelope"></i> <?php echo e($profile->email); ?></small></p>
                        <p class="card-text text-left"><small class="text-muted"><i class="fas fa-hammer"></i> <?php echo e($profile->role); ?></small></p>
                    </div>
                </div>
            </div>

            <!-- Profile Update Form -->
            <div class="col-md-8">
                <form class="border px-4 pt-2 pb-3" method="POST" action="<?php echo e(route('profile-update', $profile->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="inputTitle" class="col-form-label">Tên</label>
                        <input id="inputTitle" type="text" name="name" placeholder="Nhập tên" value="<?php echo e($profile->name); ?>" class="form-control">
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2 p-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="inputEmail" class="col-form-label">Email</label>
                        <input id="inputEmail" type="email" name="email" value="<?php echo e($profile->email); ?>" class="form-control">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2 p-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="inputPhone" class="col-form-label">Số điện thoại</label>
                        <input id="inputPhone" type="text" name="phone" placeholder="Nhập số điện thoại" value="<?php echo e($profile->phone ?? ''); ?>" class="form-control">
                        <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2 p-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="inputPhoto" class="col-form-label">Ảnh</label>
                        <div class="input-group">
                            <span class="input-group-btn">
                                <a id="lfm" data-input="thumbnail" data-preview="holder" class="btn btn-primary text-white">
                                    <i class="fa fa-picture-o"></i> Chọn
                                </a>
                            </span>
                            <input id="thumbnail" class="form-control" type="text" name="photo" value="<?php echo e($profile->photo); ?>">
                        </div>
                        <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="alert alert-danger mt-2 p-2"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="role" class="col-form-label">Vai trò</label>
                        <?php
                            $roles = ['admin' => 'Quản trị viên', 'user' => 'Người dùng', 'doctor' => 'Bác sĩ'];
                        ?>
                        <select name="role" class="form-control" disabled>
                            <option value="">-----Chọn vai trò-----</option>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e($profile->role == $key ? 'selected' : ''); ?>><?php echo e($value); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-success btn-sm" onclick="return confirm('Bạn có chắc chắn muốn cập nhật hồ sơ không?')">Cập nhật</button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<!-- Custom CSS -->
<style>
    .breadcrumbs {
        list-style: none;
    }
    .breadcrumbs li {
        float: left;
        margin-right: 10px;
    }
    .breadcrumbs li a:hover {
        text-decoration: none;
    }
    .breadcrumbs li .active {
        color: red;
    }
    .breadcrumbs li + li:before {
        content: "/\00a0";
    }
    .image {
        background: url('<?php echo e(asset('backend/img/background.jpg')); ?>') center/cover no-repeat;
        height: 150px;
        position: relative;
    }
    .image img {
        position: absolute;
        top: 55%;
        left: 50%;
        transform: translate(-50%, -50%);
        object-fit: cover;
    }
    i {
        font-size: 14px;
        padding-right: 8px;
    }
</style>

<!-- Scripts -->
<?php $__env->startPush('scripts'); ?>
<script src="/vendor/laravel-filemanager/js/stand-alone-button.js"></script>
<script>
    $('#lfm').filemanager('image');
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\van08\Downloads\CODYADMIN\resources\views\backend\users\profile.blade.php ENDPATH**/ ?>