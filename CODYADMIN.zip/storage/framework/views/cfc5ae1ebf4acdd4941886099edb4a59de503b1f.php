<?php $__env->startSection('title','CODY || Danh sách Tin Tức Công Ty'); ?>

<?php $__env->startSection('main-content'); ?>

<div class="card shadow mb-4">
    <div class="row">
        <div class="col-md-12">
           <?php echo $__env->make('backend.layouts.notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>

    <div class="card-header py-3">
      <h6 class="m-0 font-weight-bold text-primary float-left">Danh sách Tin Tức Công Ty</h6>
      <a href="<?php echo e(route('company_news.create')); ?>" class="btn btn-primary btn-sm float-right">
          <i class="fas fa-plus"></i> Thêm Tin Tức
      </a>
    </div>

    <div class="card-body">
      <div class="table-responsive">
        <?php if($news->count() > 0): ?>
        <table class="table table-bordered table-hover" id="news-dataTable" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>#</th>
              <th>Tiêu đề</th>
              <th>Ảnh</th>
              <th>Ngày xuất bản</th>
              <th>Hành động</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td><?php echo e($item->title); ?></td>
                    <td>
                        <?php if($item->image): ?>
                            <img src="<?php echo e(asset('storage/'.$item->image)); ?>" class="img-fluid" style="max-width:80px">
                        <?php else: ?>
                            <img src="<?php echo e(asset('backend/img/no-image.png')); ?>" class="img-fluid" style="max-width:80px">
                        <?php endif; ?>
                    </td>
                    <td><?php echo e(\Carbon\Carbon::parse($item->published_at)->format('d-m-Y')); ?></td>
                    <td>
                        <a href="<?php echo e(route('company_news.edit', $item->id)); ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-edit"></i>
                        </a>
                        <form method="POST" action="<?php echo e(route('company_news.destroy', $item->id)); ?>" class="d-inline">
                          <?php echo csrf_field(); ?> 
                          <?php echo method_field('delete'); ?>
                          <button type="submit" class="btn btn-danger btn-sm dltBtn">
                              <i class="fas fa-trash-alt"></i>
                          </button>
                        </form>
                    </td>
                </tr>  
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <span style="float:right"><?php echo e($news->links()); ?></span>
        <?php else: ?>
          <h6 class="text-center">Không có tin tức nào! Vui lòng thêm mới.</h6>
        <?php endif; ?>
      </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
  <link href="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.min.css" />
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
  <script src="<?php echo e(asset('backend/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/2.1.2/sweetalert.min.js"></script>

  <script>
      $(document).ready(function(){
          $('#notification-dataTable').DataTable({
              "columnDefs": [
                  {
                      "orderable": false,
                      "targets": [4]
                  }
              ]
          });

          $('.dltBtn').click(function(e){
              e.preventDefault();
              var form = $(this).closest('form');

              swal({
                  title: "Bạn có chắc không?",
                  text: "Sau khi xóa, bạn sẽ không thể khôi phục dữ liệu này!",
                  icon: "warning",
                  buttons: true,
                  dangerMode: true,
              })
              .then((willDelete) => {
                  if (willDelete) {
                      form.submit();
                  } else {
                      swal("Dữ liệu của bạn vẫn an toàn!");
                  }
              });
          });
      });
  </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\van08\Downloads\CODYADMIN\resources\views\backend\company_news\index.blade.php ENDPATH**/ ?>