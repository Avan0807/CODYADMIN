<?php $__env->startSection('title','CODY || Chi tiết thông báo chiến dịch'); ?>

<?php $__env->startSection('main-content'); ?>
<div class="card">
  <h5 class="card-header">Chi tiết Thông báo Chiến Dịch</h5>
  <div class="card-body">
    <?php if($campaign_notification): ?>
        <div class="py-4">
            <strong>Tiêu đề:</strong> <?php echo e($campaign_notification->title); ?><br>
            <strong>Đối tượng nhận:</strong> <?php echo e(ucfirst($campaign_notification->target_audience)); ?><br>
            <strong>Ngày tạo:</strong> <?php echo e($campaign_notification->created_at->format('F d, Y h:i A')); ?>

        </div>
        <hr/>
        <h5 class="text-center" style="text-decoration:underline"><strong>Nội dung Thông báo</strong></h5>
        <p class="py-5"><?php echo e($campaign_notification->message); ?></p>
    <?php else: ?>
        <h5 class="text-center">Không tìm thấy thông báo chiến dịch!</h5>
    <?php endif; ?>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\van08\Downloads\CODYADMIN\resources\views\backend\campaign_notifications\show.blade.php ENDPATH**/ ?>